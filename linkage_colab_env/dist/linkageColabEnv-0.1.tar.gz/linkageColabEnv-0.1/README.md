Download, install and configure an environment to perform data engineering and data science on Google Colab, using Java, Spark and Elasticsearch.
